# QA Journey

This repo is dedicated to improving core Java skills and building automation frameworks from scratch.

## 📅 Day 1 - Java Basics Practice

**Programs:**
- Reverse a String
- Find duplicate characters in a string
- Print even and odd numbers from an array

More coming soon. Follow daily tasks!